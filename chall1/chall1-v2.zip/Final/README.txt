x.sh: file lệnh gốc
x_crontab.sh: file cài đặt chạy cronjob cho x.sh